﻿using IPALogger = IPA.Logging.Logger;

namespace Song_Refresh_Button_BSIPA
{
    internal static class Logger
    {
        public static IPALogger log { get; set; }
    }
}
