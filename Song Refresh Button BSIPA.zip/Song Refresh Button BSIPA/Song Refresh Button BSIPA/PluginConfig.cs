﻿namespace Song_Refresh_Button_BSIPA
{
    internal class PluginConfig
    {
        public bool RegenerateConfig = true;
    }
}
